import { classify } from '../src/engine/classify'
import { buildChecklist } from '../src/engine/filter'
import { PRESETS } from '../src/data/presets'

const EXPECTED: Record<string, string> = {
  Stethoscope: 'I',
  'Reusable surgical scissors': 'I',
  'Digital thermometer': 'IIa',
  'Hemodialysis machine': 'IIb',
  'AI sepsis-prediction software': 'III',
}

let failures = 0
for (const p of PRESETS) {
  const c = classify(p.profile)
  const cl = buildChecklist(p.profile, c)
  const ok = c.euClass === EXPECTED[p.label]
  if (!ok) failures++
  console.log(
    `${ok ? 'PASS' : 'FAIL'}  ${p.label.padEnd(30)} → Class ${c.euClass.padEnd(4)} (${c.decidingRule.rule}, expected ${EXPECTED[p.label]})` +
      `  | req ${cl.required.length} / cond ${cl.conditional.length} / elim ${cl.eliminated.length} | saved ~${cl.hoursSaved}h (${cl.reductionPct}%)`
  )
  if (c.specialLabels.length) console.log(`      special: ${c.specialLabels.join(', ')}`)
}
// Rule-tie regression: when several rules independently yield the strictest class,
// the class is stable and a caveat names every co-deciding rule (Annex VIII 3.5).
// Real case: ICU monitor parsed with body-orifice probes — Rule 5 and Rule 10 both → IIb.
{
  const tieProfile = {
    name: 'ICU multi-parameter monitor (rule-tie case)',
    intendedUse: 'Continuous ECG/SpO2/invasive BP monitoring in intensive care.',
    invasiveness: 'body-orifice',
    duration: 'long-term',
    active: true,
    softwareImpact: 'inform-decisions',
    sterile: false,
    measuring: true,
    reusableSurgical: false,
    contactCnsOrHeart: false,
    channelsBlood: false,
    modifiesBloodComposition: false,
    medicinalSubstance: false,
    monitorsVitalParams: true,
    vitalParamVariationDangerous: true,
    energy: 'low',
    market: 'both',
  } as const
  const c = classify(tieProfile)
  const tieCaveat = c.caveats.find((cv) => cv.includes('independently yield'))
  const ok = c.euClass === 'IIb' && tieCaveat !== undefined && tieCaveat.includes('Rule 5') && tieCaveat.includes('Rule 10')
  if (!ok) failures++
  console.log(
    `${ok ? 'PASS' : 'FAIL'}  ${'Rule-tie: ICU monitor'.padEnd(30)} → Class ${c.euClass.padEnd(4)} (${c.decidingRule.rule}, expected IIb + tie caveat)`
  )
  if (tieCaveat) console.log(`      caveat: ${tieCaveat}`)
}

console.log(failures === 0 ? '\nAll demo devices classify as expected.' : `\n${failures} FAILURES`)
process.exit(failures === 0 ? 0 : 1)
